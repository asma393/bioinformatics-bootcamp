mkdir bioinformatics_bootcamp
cd bioinformatics_bootcamp
courses notes practice datasets
mkdir courses notes practise datasets
pwd
ls
touch practice/test.txt
pwd
ls
mkdir -p courses notes practice datasets
ls
rm -r practise
ls
touch practice/test.txt
ls practice
nano practice/day1_linux_practice.sh
pwd
ls
cd practise
cd practice
pwd
ls
pwd
/home/bouafifasma9/bioinformatics_bootcamp
bouafifasma9@cloudshell:~/bioinformatics_bootcamp$ls
bouafifasma9@cloudshell:~/bioinformatics_bootcamp$lstouch training_day1.txt
touch training_day1.txt
ls
nano training_day1.txt
cat training_day1.txt
pwd
ls
cd
pwd
ls
cd bioinformatics_bootcamp
cd practice
pwd
ls
touch linux exercice2.txt
ls
nano linux exercice2.txt
cat linux exercice2-txt
cat linux exercise2.txt
ls
cat exercice2.txt linux
cat exercice2.txt
cd bioinformatics_bootcamp
pwd
cd bioinformatics_bootcamp
cd
pwd
ls
cd bioinformatics_bootcamp
cd practice
pwd
touch training exercice 2.txt
ls
nano exercice2.txt
cat exercice2.txt
cd
cd..
cd
cd ..
cd
cd bioinformatics bootcamp
cd boinformatics_bootcamp
cd ..
ls
Welcome to Cloud Shell! Type "help" to get started, or type "gemini" to try prompting with Gemini CLI.
To set your Cloud Platform project in this session use `gcloud config set project [PROJECT_ID]`.
You can view your projects by running `gcloud projects list`.
bouafifasma9@cloudshell:~$ cd
bouafifasma9@cloudshell:~$ cd bioinformatics bootcamp
-bash: cd: too many arguments
bouafifasma9@cloudshell:~$ cd boinformatics_bootcamp
-bash: cd: boinformatics_bootcamp: No such file or directory
bouafifasma9@cloudshell:~$ cd ..
bouafifasma9@cloudshell:/home$ cd bioinformatics_bootcamp
ls
cd bioinformatics_bootcamp
cd practice
pwd
nano genes.fasta
cat genes.fasta
head genes.fasta
tail genes.fasta
head genes.fasta
tail genes.fasta
grep ATG genes.fasta
wc _l genes.fasta
wc -l genes.fasta
pwd
ls
cat -n genes.fasta
wc -l genes.fasta
grep ">" genes.fasta
grep -c ">" genes.fasta 
grep ATG genes.fasta
grep -c ">" genes.fasta
grep "<" genes.fasta
grep ">" genes.fasta
grep ">" genes.fasta | cut-c2
grep ">" genes.fasta | cut -c2-
grep GGG genes.fasta
grep -B1 GGG genes.fasta
grep -n GGG genes.fasta
cat -n genes.fasta
grep -B1 ATG genes.fasta
grep ">" genes.fasta | wc-l
grep ">" genes.fasta | wc -l
cat n- genes.fasta
cat -n genes.fasta
grep ">" genes.fasta | sort | uniq
grep ">" genes.fasta |sort | uniq | wc -l
awk '{print $0}' genes.fasta
awk '{print $0}' genes.fasta 
awk '{print NR, $0}' genes.fasta 
grep ">" genes.fasta | '{print $1}'
grep ">" genes.fasta | awk '{print $1}'
grep ">" genes.fasta | awk '{print substr($1,2)}'
awk '!/^>/ {print length($0)}' genes.fasta
awk '/^>/ {gene=$0} !/^>/ {print gene, length($0)}' genes.fasta
grep -v ">" genes.fasta
grep -v ">" genes.fasta | wc -l 
awk '/^>/ {gene=$0} !/^>/ {print gene, length($0)}' genes.fasta
grep -v ">" genes.fasta | awk '{print length($0)}' 
grep -v ">" genes.fasta | awk '{print length($0)}' | sort -n
nano mutations.txt
cat mutations.txt 
cut -d " " -f1 mutations.txt
cut -d " " -f2 mutations.txt
cut -d " " -f3 mutations.txt 
cut -d " " -f1 mutations.txt | sort | uniq-c
cut -d " " -f1 mutations.txt | sort | uniq -c
wc -l mutations.txt
cut d " " -f3 mutations.txt
cd / bioinformtics_ bootcamp / practice
cd/bioinformatics_bootcamp/practice
cd bioinformatics_bootcamp 
cd practice
pwd
nano cancer mutations.txt
cat cancer mutations.txt
cut d " " -f1 cancer mutations.txt
cut -d " " -f1 cancer mutations.txt
cut -d " " -f1 cancer mutations.txt | sort | uniq -c
grep TP53 cancer mutations.txt
grep chr17 cancer mutations.txt
cut -d " " -f1 cancer mutations.txt | sort | uniq -c > mutations_summary.txt
cat mutations_summary.txt
cd bioinformatics_bootcamp
cd practice
pwd
nano cancer dataset.txt
nano cancer_dataset.txt
ls
cat cancer_dataset.txt
wc -l cancer_dataset.txt
grep TP53 cancer_dataset.txt
grep Chr17 cancer_dataset.txt
grep chr17 cancer_dataset.txt
cut -d " " -f1 cancer_dataset 
cut -d" " -f1 cancer_dataset 
cut -d " " -f1 cancer_dataset.txt
cut -d " " -f1 cancer_dataset | sort| uniq-c 
cut -d " " -f1 cancer_dataset | sort | uniq -c 
cut -d " " -f1 cancer_dataset | sort| uniq -c
cut -d " " -f1 cancer_dataset | sort | uniq  -c
cut -d " " -f1 cancer_dataset.txt | sort | uniq -c
cut -d " " -f1 cancer_dataset.txt | sort | uniq -c > gene mutation_summary.txt
cut -d " " -f1 cancer_dataset.txt | sort | unis -c > gene_mutation_ summary.txt
cut -d " " -f1 cancer_dataset.txt | sort | uniq -c > gene_mutation_summary.txt
cut -d " " -f1 cancer_dataset-txt | sort | uniq -c > gene _ mutation_ summary.txt
cut -d " " -f1 cancer_datset.txt | sort | uniq -c > gene_mutation_summary.txt
cut -d " " -f1 cancer_ dataset.txt |sort|uniq -c > gene_mutation_summary.txt  
cut -d " " -f1 cancer_dataset.txt | sort | uniq -c > gene_mutation_summary.txt
cat gene_mutation_summary.txt
cut -d " " -f1 cancer_dataset.txt | awk '{print $1, length($1)}'
ls
ls bioinformatic_bootcamp
ls bioinformatics_bootcamp
ls bioinformatics_bpwd
ls / bioinformatics_bootcamp
ls/biopwd
ls
cd ~/bioinformatics_bootcamp
ls
ls practice
cd practice
ls
